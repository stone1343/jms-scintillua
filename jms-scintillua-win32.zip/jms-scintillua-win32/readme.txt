jms-scintillua-win32.zip is Windows version of SciTE 3.7.5. + Scintillua 3.7.5 + my customization:
 - Commented out markdown lexer (lexers\lpeg.properties)
 - Customized version of SciTEGlobal.properties
 - Added startup.lua plus jms and jms-dark themes
 - Sample SciTEUser.properties is provided, though it doesn't do anything

Usage:
 - Unzip
 - Pin SciTE.exe to taskbar or Start menu
 - Paste shortcut of SciTE.exe to shell:sendto
 - Optionally copy SciTEUser.properties to %USERPROFILE%
 - In Windows 10, I find it helpful to right-click on SciTE.exe, Properties->Compatibility, Select "Disable display scaling on high DPI settings"
 - Consider using Notepad Replacer ( https://www.binaryfortress.com/NotepadReplacer/ )
