local property = require('lexer').property

property['colour.black'] = '#111111'
property['colour.grey'] = '#888888'
property['colour.white'] = '#FFFFFF'
property['colour.red'] = '#FF0000'
property['colour.orange'] = '#EE8800'
property['colour.green'] = '#00CC00'
property['colour.blue'] = '#0000FF'
property['colour.purple'] = '#9900EE'

-- Default style.
property['style.default'] = 'fore:$(colour.black),back:$(colour.white)'

-- Token styles.
property['style.nothing'] = ''
property['style.whitespace'] = '$(style.nothing)'
property['style.identifier'] = 'fore:$(colour.black)'
property['style.comment'] = 'fore:$(colour.grey)'
property['style.error'] = 'fore:$(colour.red)'
property['style.constant'] = 'fore:$(colour.orange)'
property['style.definition'] = 'fore:$(colour.orange)'
property['style.embedded'] = 'fore:$(colour.orange)'
property['style.label'] = 'fore:$(colour.orange)'
property['style.regex'] = 'fore:$(colour.orange)'
property['style.variable'] = 'fore:$(colour.orange)'
property['style.number'] = 'fore:$(colour.green)'
property['style.class'] = 'fore:$(colour.blue)'
property['style.function'] = 'fore:$(colour.blue)'
property['style.keyword'] = 'fore:$(colour.blue)'
property['style.operator'] = 'fore:$(colour.blue)'
property['style.preprocessor'] = 'fore:$(colour.blue)'
property['style.tag'] = 'fore:$(colour.blue)'
property['style.type'] = 'fore:$(colour.blue)'
property['style.string'] = 'fore:$(colour.purple)'

-- Predefined styles.
property['style.indentguide'] = 'fore:$(colour.grey)'
