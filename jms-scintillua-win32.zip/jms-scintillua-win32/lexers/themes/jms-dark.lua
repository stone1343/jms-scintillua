local property = require('lexer').property

property['colour.black'] = '#222222'
property['colour.grey'] = '#888888'
property['colour.white'] = '#EEEEEE'
property['colour.red'] = '#C4393F'
property['colour.orange'] = '#F19939'
property['colour.green'] = '#41B345'
property['colour.blue'] = '#2374BC'
property['colour.purple'] = '#8B72BD'

-- Default style.
property['style.default'] = 'fore:$(colour.white),back:$(colour.black)'

-- Token styles.
property['style.nothing'] = ''
property['style.whitespace'] = '$(style.nothing)'
property['style.identifier'] = 'fore:$(colour.white)'
property['style.comment'] = 'fore:$(colour.grey)'
property['style.error'] = 'fore:$(colour.red)'
property['style.constant'] = 'fore:$(colour.orange)'
property['style.definition'] = 'fore:$(colour.orange)'
property['style.embedded'] = 'fore:$(colour.orange)'
property['style.label'] = 'fore:$(colour.orange)'
property['style.regex'] = 'fore:$(colour.orange)'
property['style.variable'] = 'fore:$(colour.orange)'
property['style.number'] = 'fore:$(colour.green)'
property['style.class'] = 'fore:$(colour.blue)'
property['style.function'] = 'fore:$(colour.blue)'
property['style.keyword'] = 'fore:$(colour.blue)'
property['style.operator'] = 'fore:$(colour.blue)'
property['style.preprocessor'] = 'fore:$(colour.blue)'
property['style.tag'] = 'fore:$(colour.blue)'
property['style.type'] = 'fore:$(colour.blue)'
property['style.string'] = 'fore:$(colour.purple)'

-- Predefined styles.
property['style.indentguide'] = 'fore:$(colour.grey)'
