-- Copyright 2006-2017 Mitchell mitchell.att.foicica.com. See LICENSE.
-- Null LPeg lexer.

local M = {_NAME = 'null'}

return M
